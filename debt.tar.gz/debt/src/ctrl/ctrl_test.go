package ctrl

import(
	"testing"
)

func TestSubGraph(t *testing.T){
	SubGraph()
}
