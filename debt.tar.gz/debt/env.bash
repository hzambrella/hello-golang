export GOPATH=home/haozhao/hzstudy/debt:home/haozhao/hzstudy/debt/src/vendor
export PJPATH=home/haozhao/hzstudy/debt
